#!/usr/bin/env python3
import os, json, tempfile, subprocess, time
from queue_client import QueueClient
from git import Repo
from dotenv import load_dotenv
from github import Github

load_dotenv()
qc = QueueClient()
REPO = os.getenv('REPO_PATH','./repo')
GITHUB_PAT = os.getenv('GITHUB_PAT','')
GITHUB_USERNAME = os.getenv('GITHUB_USERNAME','')
GITHUB_REPO = os.getenv('GITHUB_REPO','')
PROTECTED_BASE = os.getenv('PROTECTED_BRANCH','main')

def apply_and_push(result: dict):
    repo = Repo(REPO)
    branch = f"ai/{result.get('task_id')[:8]}"
    repo.git.checkout('HEAD', b=branch)
    patches = result.get('patches', [])
    for p in patches:
        path = os.path.join(REPO, p['path'])
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if p.get('type') == 'full':
            with open(path, 'w', encoding='utf-8') as f:
                f.write(p.get('content',''))
        else:
            tmp = tempfile.NamedTemporaryFile(delete=False)
            tmp.write(p.get('diff','').encode('utf-8'))
            tmp.flush()
            subprocess.run(['patch','-p0','-i', tmp.name], cwd=REPO)
    repo.git.add(A=True)
    repo.index.commit(f"AI auto patch {result.get('task_id')}")
    origin = repo.remote(name='origin')
    origin.push(branch)
    print('[Patcher] pushed', branch)
    # Create PR with required checks note
    if GITHUB_PAT and GITHUB_REPO and GITHUB_USERNAME:
        g = Github(GITHUB_PAT)
        gh_repo = g.get_repo(f"{GITHUB_USERNAME}/{GITHUB_REPO}")
        title = f"AI patch: {result.get('task_id')[:8]}"
        body = result.get('explanation','AI generated patch') + '\n\nVerifier:\n' + json.dumps(result.get('verifier',{}), indent=2)
        pr = gh_repo.create_pull(title=title, body=body, head=branch, base=PROTECTED_BASE)
        # add label and comment to indicate required checks
        pr.create_issue_comment('Automated PR by AI agent. CI checks required before merge.')
        pr.add_to_labels('ai:auto')
        print('[Patcher] PR created:', pr.html_url)
    else:
        print('[Patcher] GitHub credentials missing; branch pushed only')

if __name__ == '__main__':
    print('Patcher running') 
    while True:
        job = qc.pop_apply()
        if not job:
            time.sleep(0.8)
            continue
        try:
            apply_and_push(job)
        except Exception as e:
            print('Patcher error', e)
