# conftest.py - ensure project root is on sys.path for tests
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
