# dashboard/app.py - cleaned scaffold with sessions, RQ, DLQ, and Prometheus metrics
import os, time, sys, logging, json, threading
from functools import wraps
from flask import Flask, jsonify, request, Response, render_template, session
from dotenv import load_dotenv

# ensure project root on sys.path for tests
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

# load .env if present
basedir = os.path.dirname(os.path.dirname(__file__))
load_dotenv(os.path.join(basedir, '.env'))

# prometheus client optional import
try:
    from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST
except Exception:
    Counter = Gauge = Histogram = generate_latest = CONTENT_TYPE_LATEST = None

# redis & rq optional
try:
    import redis as _redis_lib
    from rq import Queue as _RQ_Queue
except Exception:
    _redis_lib = None
    _RQ_Queue = None

app = Flask(__name__)
# set secure cookie settings; ensure you run behind HTTPS in production
app.secret_key = os.getenv('FLASK_SECRET', 'change-me')
from datetime import timedelta
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.permanent_session_lifetime = timedelta(hours=6)

app.start_time = time.time()
logger = logging.getLogger('dashboard')
logger.setLevel(logging.INFO)

# Metrics
if Counter:
    AI_CHAT_REQUESTS = Counter('ai_chat_requests_total', 'Total AI chat requests', ['agent'])
    AI_CHAT_ERRORS = Counter('ai_chat_errors_total', 'AI chat errors', ['agent'])
    AI_LLM_COST = Counter('ai_llm_cost_total', 'Estimated LLM cost in USD', ['model'])
    AI_LLM_TOKENS_PROMPT = Counter('ai_llm_tokens_prompt_total', 'Prompt tokens used', ['model'])
    AI_LLM_TOKENS_COMPLETION = Counter('ai_llm_tokens_completion_total', 'Completion tokens used', ['model'])
    AI_TASK_LATENCY = Histogram('ai_task_latency_seconds', 'Task processing latency seconds', buckets=(0.01,0.05,0.1,0.25,0.5,1,2,5,10))
    AI_QUEUE_GAUGE = Gauge('ai_queue_tasks', 'Number of tasks in queue')
    AI_WORKER_HEARTBEAT = Gauge('ai_worker_last_heartbeat', 'Timestamp of last worker heartbeat')
    AI_DQL_DEPTH = Gauge('ai_tasks_dlq_depth','Dead letter queue depth')
else:
    AI_CHAT_REQUESTS = AI_CHAT_ERRORS = AI_LLM_COST = AI_TASK_LATENCY = AI_QUEUE_GAUGE = AI_WORKER_HEARTBEAT = AI_DQL_DEPTH = None
    AI_LLM_TOKENS_PROMPT = AI_LLM_TOKENS_COMPLETION = None

# helpers
def get_redis_client():
    REDIS_URL = os.getenv('REDIS_URL')
    if not REDIS_URL or not _redis_lib:
        return None
    try:
        return _redis_lib.from_url(REDIS_URL, decode_responses=True)
    except Exception as e:
        logger.warning('redis connect failed: %s', e)
        return None

def get_rq_queue():
    REDIS_URL = os.getenv('REDIS_URL')
    if not REDIS_URL or not _redis_lib or not _RQ_Queue:
        return None
    try:
        conn = _redis_lib.from_url(REDIS_URL)
        return _RQ_Queue(connection=conn)
    except Exception:
        return None

# auth middleware: session admin OR API key via header/query
def require_api_key(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if session.get('admin'):
            return f(*args, **kwargs)
        API_KEY_LOCAL = os.getenv('API_KEY') or os.getenv('AI_API_KEY') or None
        if not API_KEY_LOCAL:
            return f(*args, **kwargs)
        key = request.headers.get('X-API-KEY') or request.args.get('api_key')
        if not key or key != API_KEY_LOCAL:
            return jsonify({'error':'unauthorized'}), 401
        return f(*args, **kwargs)
    return wrapped

@app.route('/admin/login', methods=['POST'])
def admin_login():
    data = request.get_json(force=True, silent=True) or {}
    key = data.get('api_key')
    API_KEY_LOCAL = os.getenv('API_KEY') or os.getenv('AI_API_KEY') or None
    if not API_KEY_LOCAL:
        return jsonify({'error':'no_api_key_configured'}), 400
    if not key or key != API_KEY_LOCAL:
        return jsonify({'error':'unauthorized'}), 401
    session['admin'] = True
    session.permanent = True
    return jsonify({'status':'ok'})

@app.route('/admin/logout', methods=['POST'])
def admin_logout():
    session.pop('admin', None)
    return jsonify({'status':'ok'})

@app.route('/api/overview')
def overview():
    uptime = time.time() - app.start_time
    return jsonify({'uptime': uptime, 'status':'ok'})

@app.route('/api/chat', methods=['POST'])
@require_api_key
def chat():
    try:
        from ai.adapter import is_safe, call_openai
    except Exception:
        return jsonify({'error':'adapter_missing'}), 500
    data = request.get_json(force=True, silent=True) or {}
    text = data.get('text','')
    agent = data.get('agent','default')
    model = data.get('model', os.getenv('AI_DEFAULT_MODEL','gpt-4o-mini'))
    if not is_safe(text):
        if AI_CHAT_ERRORS: AI_CHAT_ERRORS.labels(agent=agent).inc()
        return jsonify({'error':'blocked','reply':'[blocked]'}), 400
    if AI_CHAT_REQUESTS: AI_CHAT_REQUESTS.labels(agent=agent).inc()
    start = time.time()
    messages = [{'role':'user','content': text}]
    resp = call_openai(messages, model=model)
    duration = time.time() - start
    if AI_TASK_LATENCY: AI_TASK_LATENCY.observe(duration)
    cost = 0.0
    if isinstance(resp, dict):
        meta = resp.get('meta') or {}
        cost = meta.get('cost') or resp.get('cost') or 0.0
    try:
        if AI_LLM_COST: AI_LLM_COST.labels(model=model).inc(float(cost))
    except Exception:
        pass
    return jsonify(resp)

@app.route('/api/submit_task', methods=['POST'])
@require_api_key
def submit_task():
    data = request.get_json(force=True, silent=True) or {}
    task = {
        'task_id': data.get('task_id', str(time.time()).replace('.','_')),
        'agent': data.get('agent','default'),
        'payload': data.get('payload', {})
    }
    # RQ enqueue
    q = get_rq_queue()
    if q:
        try:
            job = q.enqueue_call(func='worker.rq_worker.rq_process_task', args=(task,), result_ttl=86400, failure_ttl=604800)
            return jsonify({'status':'queued_rq','job_id':job.get_id()}), 202
        except Exception as e:
            return jsonify({'error':'rq_enqueue_failed','message':str(e)}), 500
    # Redis LPUSH fallback
    rc = get_redis_client()
    if rc:
        try:
            rc.lpush('ai_tasks', json.dumps(task))
            try:
                if AI_QUEUE_GAUGE: AI_QUEUE_GAUGE.set(rc.llen('ai_tasks'))
            except Exception:
                pass
            try:
                if AI_DQL_DEPTH: AI_DQL_DEPTH.set(rc.llen('ai_tasks_dlq'))
            except Exception:
                pass
            return jsonify({'status':'queued','task_id':task['task_id']}), 202
        except Exception as e:
            return jsonify({'error':'redis_push_failed','message':str(e)}), 500
    # filesystem fallback
    qdir = os.getenv('AI_TASK_DIR', '/tmp/ai_tasks')
    os.makedirs(qdir, exist_ok=True)
    p = os.path.join(qdir, f"{task['task_id']}.json")
    with open(p, 'w') as fh:
        fh.write(json.dumps(task))
    try:
        if AI_QUEUE_GAUGE: AI_QUEUE_GAUGE.set(len([x for x in os.listdir(qdir) if x.endswith('.json')]))
    except Exception:
        pass
    return jsonify({'status':'queued_fs','task_id':task['task_id']}), 202

@app.route('/metrics')
def metrics():
    try:
        data = generate_latest()
        return Response(data, mimetype=CONTENT_TYPE_LATEST)
    except Exception:
        return Response('')  # prometheus not available

# DLQ admin endpoints
@app.route('/admin/dlq/list', methods=['GET'])
@require_api_key
def dlq_list():
    rc = get_redis_client()
    if not rc:
        return jsonify({'error':'no_redis'}), 400
    try:
        items = rc.lrange('ai_tasks_dlq', 0, 99)
        parsed = [json.loads(i) for i in items]
        return jsonify({'count': len(parsed), 'items': parsed})
    except Exception as e:
        return jsonify({'error':'dlq_list_failed','message':str(e)}), 500

@app.route('/admin/dlq/requeue', methods=['POST'])
@require_api_key
def dlq_requeue():
    rc = get_redis_client()
    if not rc:
        return jsonify({'error':'no_redis'}), 400
    data = request.get_json(force=True, silent=True) or {}
    count = int(data.get('count', 1))
    try:
        moved = []
        for _ in range(count):
            item = rc.rpop('ai_tasks_dlq')
            if not item: break
            obj = json.loads(item)
            rc.lpush('ai_tasks', json.dumps(obj.get('payload') or {}))
            moved.append(obj)
        try:
            if AI_DQL_DEPTH: AI_DQL_DEPTH.set(rc.llen('ai_tasks_dlq'))
        except Exception:
            pass
        return jsonify({'moved': len(moved), 'items': moved})
    except Exception as e:
        return jsonify({'error':'dlq_requeue_failed','message':str(e)}), 500

@app.route('/dlq')
@require_api_key
def dlq_page():
    return render_template('dlq.html')

# background updater for DLQ depth
def _dlq_updater(interval=30):
    def run():
        while True:
            try:
                rc = get_redis_client()
                if rc and AI_DQL_DEPTH:
                    AI_DQL_DEPTH.set(rc.llen('ai_tasks_dlq'))
                time.sleep(interval)
            except Exception:
                time.sleep(interval)
    t = threading.Thread(target=run, daemon=True)
    t.start()

# start updater
try:
    _dlq_updater()
except Exception:
    pass

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8099)
