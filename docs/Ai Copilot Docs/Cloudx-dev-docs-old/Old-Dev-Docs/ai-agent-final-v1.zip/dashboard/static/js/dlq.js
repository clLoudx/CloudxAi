async function loginApiKeySession(key){
  const res = await fetch('/admin/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({api_key:key}), credentials:'same-origin'});
  return res.status === 200;
}
function setHeaderKey(k){
  if(k) sessionStorage.setItem('AI_AGENT_API_KEY_HEADER', k);
  else sessionStorage.removeItem('AI_AGENT_API_KEY_HEADER');
  updateAuthModeDisplay();
}
function getHeaderKey(){ return sessionStorage.getItem('AI_AGENT_API_KEY_HEADER') || ''; }
function updateAuthModeDisplay(){
  const el = document.getElementById('auth_mode');
  const hk = getHeaderKey();
  if(hk) el.textContent = 'Using header auth';
  else el.textContent = 'Using session auth (default)';
}
async function api(path, method='GET', body=null){
  const headers = {'Content-Type':'application/json'};
  const hk = getHeaderKey();
  const opts = {method, headers, credentials:'same-origin'};
  if(hk) headers['X-API-KEY'] = hk;
  if(body) opts.body = JSON.stringify(body);
  const res = await fetch(path, opts);
  if(res.status === 401){
    alert('Unauthorized. Please authenticate (session login or header API key).');
    showModal();
    throw new Error('unauthorized');
  }
  return res.json();
}
async function refresh(){
  try{
    const res = await api('/admin/dlq/list');
    const tbody = document.querySelector('#dlq tbody');
    tbody.innerHTML='';
    if(res && res.items){
      res.items.forEach((it, idx)=>{
        const tr = document.createElement('tr');
        const timeVal = it.time ? new Date(it.time*1000).toLocaleString() : '';
        tr.innerHTML = `<td>${idx}</td><td>${it.job_id||'n/a'}</td><td>${timeVal}</td><td>${it.error||''}</td><td><pre>${JSON.stringify(it.payload||{},null,2).substring(0,200)}</pre></td>`;
        tbody.appendChild(tr);
      });
    } else {
      tbody.innerHTML='<tr><td colspan="5">No items or error (check console)</td></tr>';
    }
  }catch(e){ console.error(e); }
}
document.getElementById('refresh').addEventListener('click', refresh);
document.getElementById('requeue_one').addEventListener('click', async ()=>{
  const res = await api('/admin/dlq/requeue','POST',{count:1});
  alert('Moved: '+(res.moved||0));
  await refresh();
});
document.getElementById('requeue_all').addEventListener('click', async ()=>{
  const res = await api('/admin/dlq/requeue','POST',{count:100});
  alert('Moved: '+(res.moved||0));
  await refresh();
});

// Session login modal behavior
const modal = document.getElementById('modal');
const loginBtn = document.getElementById('login_btn');
const saveBtn = document.getElementById('save_key');
const cancelBtn = document.getElementById('cancel_key');
loginBtn.addEventListener('click', ()=>{ showModal(); });
saveBtn.addEventListener('click', async ()=>{
  const v = document.getElementById('api_input').value.trim();
  if(!v){ alert('Enter API key'); return; }
  const ok = await loginApiKeySession(v);
  if(ok) { hideModal(); await refresh(); }
  else alert('Login failed');
});
cancelBtn.addEventListener('click', ()=>{ hideModal(); });

function showModal(){ document.getElementById('modal').style.display='block'; document.getElementById('api_input').value=''; document.getElementById('api_input').focus(); }
function hideModal(){ document.getElementById('modal').style.display='none'; }

// Header API key modal behavior
const modal_key = document.getElementById('modal_key');
const apikeyBtn = document.getElementById('apikey_btn');
const saveBtnHeader = document.getElementById('save_key_header');
const cancelBtnHeader = document.getElementById('cancel_key_header');
apikeyBtn.addEventListener('click', ()=>{ showModalHeader(); });
saveBtnHeader.addEventListener('click', ()=>{
  const v = document.getElementById('api_input_key').value.trim();
  if(!v){ alert('Enter API key'); return; }
  setHeaderKey(v); hideModalHeader(); updateAuthModeDisplay(); refresh();
});
cancelBtnHeader.addEventListener('click', ()=>{ hideModalHeader(); });

function showModalHeader(){ document.getElementById('modal_key').style.display='block'; document.getElementById('api_input_key').value=''; document.getElementById('api_input_key').focus(); }
function hideModalHeader(){ document.getElementById('modal_key').style.display='none'; }

// Clear API key header
document.getElementById('clear_key').addEventListener('click', ()=>{ setHeaderKey(''); updateAuthModeDisplay(); refresh(); });

// init
updateAuthModeDisplay();
refresh();
