// dashboard/static/js/dashboard.js
// Minimal production-ready frontend JS: SocketIO + fetch fallbacks + UI hooks
document.addEventListener('DOMContentLoaded', function () {
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');
  const chatOut = document.getElementById('chat-out');
  if (chatForm) {
    chatForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const text = chatInput.value;
      if (!text) return;
      appendMsg('you', text);
      chatInput.value = '';
      try {
        const res = await fetch('/api/chat', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text})});
        const j = await res.json();
        appendMsg('ai', j.reply || JSON.stringify(j));
      } catch (err) {
        appendMsg('ai','[error] ' + err.message);
      }
    }, false);
  }
  function appendMsg(who, text) {
    if (!chatOut) return;
    const el = document.createElement('div');
    el.className = 'msg ' + who;
    el.textContent = (who === 'you' ? 'You: ' : 'AI: ') + text;
    chatOut.appendChild(el);
    chatOut.scrollTop = chatOut.scrollHeight;
  }
  // try socket.io
  if (window.io) {
    try {
      const socket = io();
      socket.on('connect', () => console.log('socket connected'));
      socket.on('task_done', (data) => {
        appendMsg('ai', '[task_done] ' + JSON.stringify(data));
      });
    } catch(e) { console.warn('Socket init failed', e); }
  }
});
