# dashboard package init - expose app at package level for tests
from .app import app
