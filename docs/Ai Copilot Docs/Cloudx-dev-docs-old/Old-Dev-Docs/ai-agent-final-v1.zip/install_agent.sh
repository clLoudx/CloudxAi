#!/usr/bin/env bash
set -euo pipefail
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
if [ ! -f .env ]; then
  cp .env.example .env
  echo "Copied .env.example to .env. Please edit it with your keys and REPO_PATH."
fi
echo "Install complete. Run ./run_agent.sh to start the agent (mock mode by default)."
