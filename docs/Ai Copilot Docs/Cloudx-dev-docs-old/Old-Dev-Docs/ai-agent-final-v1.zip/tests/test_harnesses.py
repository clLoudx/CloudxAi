import os, json
def test_harness_files_exist():
    assert os.path.exists('repo/tests/agent_harness/test_auth.php')
    assert os.path.exists('repo/tests/agent_harness/test_streaming.php')
    assert os.path.exists('repo/tests/agent_harness/test_channels.php')
