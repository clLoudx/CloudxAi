# tests/test_api.py
import os, json
import pytest
# adapt import path to likely dashboard package
try:
    from dashboard import app as dashboard_app
except Exception:
    # fallback if app is a module-level file
    import importlib.util, sys, os
    spec = importlib.util.spec_from_file_location('dashboard_app', os.path.join(os.path.dirname(__file__), '..', 'dashboard', 'app.py'))
    dashboard_app = importlib.util.module_from_spec(spec)
    sys.modules['dashboard_app'] = dashboard_app
    spec.loader.exec_module(dashboard_app)
    dashboard_app = getattr(dashboard_app, 'app', dashboard_app)

@pytest.fixture
def client():
    dashboard_app.config['TESTING'] = True
    with dashboard_app.test_client() as client:
        yield client

def test_overview(client):
    r = client.get('/api/overview')
    assert r.status_code == 200
    j = r.get_json()
    assert 'uptime' in j

def test_chat_block(client):
    r = client.post('/api/chat', json={'agent':'ai-1','text':'rm -rf /'})
    assert r.status_code == 400 or 'blocked' in r.get_data(as_text=True).lower()

def test_mock_chat(client):
    r = client.post('/api/chat', json={'agent':'ai-1','text':'hello world'})
    assert r.status_code == 200
    j = r.get_json()
    assert 'reply' in j
