import os, json, time
from queue_client import QueueClient

def test_queue_push_and_pop():
    q = QueueClient()
    t = {'task_id':'test01','mode':'build','instructions':'do something'}
    q.push_task(t, queue='tasks')
    popped = q.reserve_task(queue='tasks')
    assert popped['task_id'] == 'test01'

def test_operations_log():
    q = QueueClient()
    q.log_operation('test_op','id123',{'a':1})
    ops = q.get_operations(limit=5)
    assert isinstance(ops, list)
