# gunicorn.conf.py
import multiprocessing
workers = 1
timeout = 120
