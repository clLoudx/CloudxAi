#!/usr/bin/env bash
set -euo pipefail
echo "Starting mock demo playback..."
# Ensure env and venv
source venv/bin/activate
export MOCK_MODE=true
docker-compose up -d redis
# start coordinator and one worker in background
nohup python3 coordinator.py >> logs/coordinator.demo.log 2>&1 &
nohup WORKER_NAME=demo-worker MOCK_MODE=true python3 worker.py tasks >> logs/worker.demo.log 2>&1 &
sleep 1
# create a sample task
python3 - <<'PY'
from queue_client import QueueClient
q=QueueClient()
q.push_task({'task_id':'demo-001','mode':'build','instructions':'Create demo endpoint','queue':'tasks'})
print('Task demo-001 queued')
PY
sleep 2
echo "Demo logs:"
tail -n 50 logs/worker.demo.log || true
tail -n 50 logs/coordinator.demo.log || true
echo "Demo complete. Check dashboard at http://127.0.0.1:8099"
