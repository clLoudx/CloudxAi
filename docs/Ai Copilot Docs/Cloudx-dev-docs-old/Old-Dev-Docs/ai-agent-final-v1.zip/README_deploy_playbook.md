# AI Agent — Final README & Deploy Playbook (Production v2)

This README consolidates the full deploy, operations, monitoring, and recovery playbook.
Drop this in the repo root and hand to SREs.

## Quick facts
- App: Flask + Gunicorn (eventlet), WEB on port 8000 (Docker) or 8099 (dev)
- Worker: RQ-based worker, pushes failures to Redis DLQ `ai_tasks_dlq`
- Metrics: Prometheus metrics exposed at `/metrics`
- Monitoring: Grafana dashboards in deploy/grafana/dashboards/
- Alerts: Prometheus rules in deploy/alert_rules_generated.yml

## Files of interest
- dashboard/: Flask app and templates
- worker/: worker code (worker/rq_worker.py)
- scripts/final_installer.sh
- scripts/build_and_export.sh
- deploy/grafana/dashboards/: Grafana JSONs
- deploy/alert_rules_generated.yml : Prometheus alert rules

## Apply patch (safe)
1. Inspect patch and ensure clean working tree:
   git status --porcelain
   git apply --stat aiagent_release.patch
   git apply --check aiagent_release.patch
2. Apply on branch:
   git checkout -b patch/apply-aiagent-release
   git am --signoff aiagent_release.patch

If conflicts, use `git am --abort` then `git apply --3way` and resolve manually.

## Build & export Docker images (on host with Docker)
chmod +x scripts/build_and_export.sh
./scripts/build_and_export.sh
# tarballs in export_images/

## Verify tarballs
sha256sum export_images/*.tar.gz

## Deploy alerts to Prometheus (example)
sudo cp deploy/alert_rules_generated.yml /etc/prometheus/rules/ai-agent-alerts.yml
# edit /etc/prometheus/prometheus.yml to include the rule file if not present
sudo systemctl reload prometheus

## Deploy Grafana dashboards (provisioning)
Place deploy/grafana/dashboards/*.json into Grafana provisioning dashboards folder
and ensure datasource points to Prometheus.

## Start services (systemd example)
sudo systemctl daemon-reload
sudo systemctl enable --now aiagent-app aiagent-rq

## Rollback
- Use backups in out_deploy/backups/
- Stop services, replace code, restart, re-run smoke tests

## Smoke tests
curl -s http://127.0.0.1:8099/api/overview | jq
curl -s -X POST http://127.0.0.1:8099/api/chat -H 'Content-Type: application/json' -d '{"text":"hello"}'

## Contacts & runbooks
See runbooks/ai-agent/ for per-alert remediation plans (ai_queue_high, ai_dlq_high, ai_worker_down).

---
End of playbook.
