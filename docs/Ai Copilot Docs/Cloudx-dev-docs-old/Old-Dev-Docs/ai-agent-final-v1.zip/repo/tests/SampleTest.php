<?php
use PHPUnit\Framework\TestCase;
final class SampleTest extends TestCase { public function testTruth(){ $this->assertTrue(true);} }
