#!/usr/bin/env bash
# final_production_v2_patch.sh
# This script applies non-destructive project-level patches created by ChatGPT.
set -euo pipefail
ROOT="/mnt/data/ai-agent-steps/Originalscript.zip_extracted"
echo "Applying patches to $ROOT"

# 1) Create /etc/ai-agent/env template locally under deploy/etc_ai_agent_env_example
mkdir -p "$ROOT/out_deploy"
cat > "$ROOT/out_deploy/etc_ai_agent_env_example" <<'ENV'
OPENAI_API_KEY=sk-REPLACE_ME
OTHER_SECRET=...
ENV
echo "Created example env at $ROOT/out_deploy/etc_ai_agent_env_example"

# 2) List files created by this patch
echo "Files added/modified by this patch:"
python - <<PY
import os, json
created = ["/mnt/data/ai-agent-steps/Originalscript.zip_extracted/ai/adapter.py", "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/tests/test_api.py", "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/app.py (modified)", "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/systemd/ai-agent.service", "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/systemd/ai-agent-worker.service", "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/nginx/ai-agent.conf", "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/alert_rules.yml", "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/.github/workflows/ci.yml"]
for p in created:
    print(p)
PY

echo "Patch applied (files created under project)."
echo "Next steps (manual):"
echo " - Review files under $ROOT (ai/adapter.py, tests/, deploy/nginx, deploy/systemd, deploy/alert_rules.yml, .github/workflows/ci.yml)"
echo " - Create a Python venv, install requirements, and run pytest locally."
echo " - Copy $ROOT/out_deploy/etc_ai_agent_env_example -> /etc/ai-agent/env (secure it) if deploying"
echo " - For production, move files in deploy/systemd to /etc/systemd/system/ and reload systemd"
exit 0
