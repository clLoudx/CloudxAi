#!/bin/bash
echo Running AI Agent
