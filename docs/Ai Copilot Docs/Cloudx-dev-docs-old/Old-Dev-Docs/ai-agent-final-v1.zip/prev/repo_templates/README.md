KooraKing repo templates.

Files:
- composer.json : composer dependencies and scripts
- phpunit.xml : PHPUnit configuration
- phpstan.neon : PHPStan config
- tests/SampleTest.php : sample test to validate CI

Place these files in the root of your KooraKing project and run `composer install` then `vendor/bin/phpunit`.
