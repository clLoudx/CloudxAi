#!/usr/bin/env python3
import os, time, json, random, signal
from dotenv import load_dotenv
from queue_client import QueueClient
from ratelimit import limits, sleep_and_retry

load_dotenv()
qc = QueueClient()
MOCK_MODE = os.getenv('MOCK_MODE','false').lower() in ('1','true','yes')
OPENAI_KEY = os.getenv('OPENAI_API_KEY','')
MODEL = os.getenv('OPENAI_MODEL','gpt-4o-mini')
MOCK_DIR = os.path.join(os.path.dirname(__file__), 'mocks')
WORKER_NAME = os.getenv('WORKER_NAME', 'worker-' + str(random.randint(1000,9999)))
running = True

try:
    import openai
    openai.api_key = OPENAI_KEY
except Exception:
    openai = None

def handle_termination(signum, frame):
    global running
    print(f'[{WORKER_NAME}] Termination signal received. Exiting.')
    running = False

import signal
signal.signal(signal.SIGTERM, handle_termination)
signal.signal(signal.SIGINT, handle_termination)

def clean_json_candidate(s: str) -> str:
    s = s.strip()
    if s.startswith('```') and '```' in s[3:]:
        s = s.split('```',2)[1]
    if '{' in s and '}' in s:
        start = s.find('{')
        end = s.rfind('}')
        return s[start:end+1]
    return s

@sleep_and_retry
@limits(calls=20, period=60)  # limit LLM calls to 20/min per worker (configurable)
def call_llm(prompt: str) -> str:
    if openai is None:
        return json.dumps({'error':'openai lib missing','raw':prompt})
    resp = openai.ChatCompletion.create(
        model=MODEL,
        messages=[{'role':'system','content':'You are a strict JSON code assistant.'},
                  {'role':'user','content': prompt}],
        temperature=0.05,
        max_tokens=2000
    )
    return resp['choices'][0]['message']['content']

def load_mock_response(mode):
    try:
        files = [f for f in os.listdir(MOCK_DIR) if f.endswith('.json')]
    except Exception:
        return {'task_id':'mock-missing','patches':[],'tests':[],'explanation':'no mocks','confidence':0}
    candidates = files
    if mode == 'fix':
        candidates = [f for f in files if 'fix' in f or 'builder' in f] or files
    chosen = random.choice(candidates)
    with open(os.path.join(MOCK_DIR, chosen),'r') as fh:
        return json.load(fh)

def perform_task_llm(task):
    prompt_template = open('prompts/worker_builder.txt').read() if task.get('mode')!='fix' else open('prompts/worker_fixer.txt').read()
    prompt = prompt_template.replace('{{TASK}}', json.dumps(task))
    raw = call_llm(prompt)
    candidate = clean_json_candidate(raw)
    parsed = json.loads(candidate)
    parsed['worker'] = WORKER_NAME
    return parsed

def perform_task(task):
    mode = task.get('mode','build')
    start = int(time.time())
    if MOCK_MODE:
        res = load_mock_response(mode)
        res.update({'task_id': task.get('task_id'), 'worker': WORKER_NAME, 'started_at': start, 'finished_at': start+1})
        return res
    else:
        try:
            parsed = perform_task_llm(task)
            parsed['started_at'] = start
            parsed['finished_at'] = int(time.time())
            return parsed
        except Exception as e:
            return {'task_id': task.get('task_id'), 'patches':[], 'explanation': f'llm_error: {e}', 'confidence':0, 'worker':WORKER_NAME, 'started_at':start, 'finished_at':int(time.time())}

def worker_loop(queue_name='tasks'):
    global running
    print(f'[{WORKER_NAME}] started, listening to queue:', queue_name)
    while running:
        task = qc.reserve_task(queue=queue_name)
        if not task:
            time.sleep(0.4)
            continue
        qc.log_operation('worker_start', task.get('task_id'), {'worker': WORKER_NAME, 'queue': queue_name})
        result = perform_task(task)
        qc.push_result(result)
        qc.log_operation('worker_finish', task.get('task_id'), {'worker': WORKER_NAME, 'queue': queue_name, 'duration': result.get('finished_at',0)-result.get('started_at',0)})
        if result.get('confidence',0) < 0.3:
            qc.push_alert({'id': WORKER_NAME + '-' + task.get('task_id'), 'task_id': task.get('task_id'), 'level':'warning', 'message':'low confidence', 'worker': WORKER_NAME})
    print(f'[{WORKER_NAME}] exiting')

if __name__ == '__main__':
    import sys
    queue = sys.argv[1] if len(sys.argv)>1 else 'tasks'
    worker_loop(queue_name=queue)
