# ai/adapter.py (tiktoken-enabled adapter with token metrics)
import os, requests, time, json, logging
from typing import List, Dict, Optional

logger = logging.getLogger("ai.adapter.tiktoken")
DEFAULT_MODEL = os.getenv("AI_DEFAULT_MODEL", "gpt-4o-mini")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
REQUEST_TIMEOUT = int(os.getenv("AI_REQUEST_TIMEOUT", "20"))

try:
    import tiktoken
    TIKTOKEN_AVAILABLE = True
except Exception:
    TIKTOKEN_AVAILABLE = False

try:
    from prometheus_client import Counter
    AI_LLM_TOKENS_PROMPT = Counter('ai_llm_tokens_prompt_total', 'Total prompt tokens used', ['model'])
    AI_LLM_TOKENS_COMPLETION = Counter('ai_llm_tokens_completion_total', 'Total completion tokens used', ['model'])
except Exception:
    AI_LLM_TOKENS_PROMPT = None
    AI_LLM_TOKENS_COMPLETION = None

def heuristic_token_estimate(text: str) -> int:
    if not text: return 0
    words = len(text.split())
    return max(1, int(words / 0.75))

def estimate_tokens_tiktoken(text: str, model: str) -> int:
    try:
        enc = tiktoken.encoding_for_model(model)
    except Exception:
        try:
            enc = tiktoken.get_encoding("cl100k_base")
        except Exception:
            return heuristic_token_estimate(text)
    return len(enc.encode(text))

def estimate_tokens(text: str, model: str = DEFAULT_MODEL) -> int:
    if TIKTOKEN_AVAILABLE:
        try:
            return estimate_tokens_tiktoken(text, model)
        except Exception as e:
            logger.warning("tiktoken failed: %s", e)
            return heuristic_token_estimate(text)
    return heuristic_token_estimate(text)

MODEL_COSTS = {
    "gpt-4o-mini": {"prompt": 0.03, "completion": 0.06},
    "gpt-4o": {"prompt": 0.06, "completion": 0.12}
}

BLACKLIST = ['rm -rf', 'shutdown', 'reboot', 'passwd', '/etc/shadow', 'import os', 'eval(', 'exec(', 'open(/etc']

def is_safe(text: str) -> bool:
    t = text.lower()
    for b in BLACKLIST:
        if b in t:
            return False
    return True

def estimate_cost(model: str, prompt_tokens: int, completion_tokens: int) -> float:
    m = MODEL_COSTS.get(model, MODEL_COSTS.get("gpt-4o-mini"))
    cost = (prompt_tokens/1000.0) * m["prompt"] + (completion_tokens/1000.0) * m["completion"]
    return round(cost, 8)

def call_openai(messages: List[Dict], model: str = DEFAULT_MODEL, api_key: Optional[str] = None, timeout: int = REQUEST_TIMEOUT):
    key = api_key or OPENAI_API_KEY
    last = messages[-1]['content'] if messages else ''
    if not is_safe(last):
        return {"error":"blocked","reply":"[blocked - unsafe content]"}
    prompt_text = "\n".join([m.get('content','') for m in messages])
    prompt_tokens = estimate_tokens(prompt_text, model=model)
    if AI_LLM_TOKENS_PROMPT is not None:
        try:
            AI_LLM_TOKENS_PROMPT.labels(model=model).inc(prompt_tokens)
        except Exception:
            pass
    if not key:
        return {"mock": True, "reply": "[MOCK] " + last, "tokens":{"prompt":prompt_tokens,"completion":0}, "cost":0.0}
    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    payload = {"model": model, "messages": messages, "temperature": 0.2}
    backoff = 1
    for attempt in range(3):
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=timeout)
            r.raise_for_status()
            body = r.json()
            choice = body.get('choices',[{}])[0]
            msg = choice.get('message') or choice.get('text') or {}
            content = msg.get('content') if isinstance(msg, dict) else str(msg)
            usage = body.get('usage', {})
            completion_tokens = usage.get('completion_tokens', 0) or 0
            prompt_tokens_reported = usage.get('prompt_tokens', prompt_tokens) or prompt_tokens
            total_cost = estimate_cost(model, prompt_tokens_reported, completion_tokens)
            if AI_LLM_TOKENS_COMPLETION is not None:
                try:
                    AI_LLM_TOKENS_COMPLETION.labels(model=model).inc(completion_tokens)
                except Exception:
                    pass
            return {"mock": False, "reply": content, "meta": {"usage": usage, "cost": total_cost}}
        except Exception as e:
            logger.warning("openai attempt %s failed: %s", attempt+1, e)
            time.sleep(backoff)
            backoff *= 2
    completion_tokens = 50
    total_cost = estimate_cost(model, prompt_tokens, completion_tokens)
    if AI_LLM_TOKENS_COMPLETION is not None:
        try:
            AI_LLM_TOKENS_COMPLETION.labels(model=model).inc(completion_tokens)
        except Exception:
            pass
    return {"error":"openai_failed","reply":"[MOCK-FALLBACK] " + last, "tokens":{"prompt":prompt_tokens,"completion":completion_tokens}, "cost": total_cost}
