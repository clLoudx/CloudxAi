# ai package
from .adapter import call_openai, is_safe
