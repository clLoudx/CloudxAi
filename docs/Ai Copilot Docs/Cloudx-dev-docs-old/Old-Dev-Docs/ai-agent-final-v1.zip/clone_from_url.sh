#!/bin/bash
set -euo pipefail
if [ -z "$1" ]; then
  echo "Usage: ./clone_from_url.sh <git_repo_url> [branch]"
  exit 1
fi
REPO_URL="$1"
BRANCH=${2:-main}
TARGET="repo"
if [ -d "$TARGET" ]; then
  echo "Target repo/ already exists. Will backup to repo_backup_$(date +%s)"
  mv "$TARGET" "${TARGET}_backup_$(date +%s)"
fi
git clone --depth 1 -b "$BRANCH" "$REPO_URL" "$TARGET"
