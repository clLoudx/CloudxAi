#!/usr/bin/env bash
set -euo pipefail
# usage: ROLE=rq ./run_rq_worker.sh
REDIS_URL=${REDIS_URL:-redis://127.0.0.1:6379/0}
export REDIS_URL
cd /opt/ai-agent || cd $(pwd)
# ensure virtualenv exists at /opt/ai-agent/venv
exec /opt/ai-agent/venv/bin/rq worker -u $REDIS_URL default
