#!/usr/bin/env bash
# Non-destructive deploy helper (does NOT run sudo actions automatically)
set -euo pipefail
ROOT="${1:-$(pwd)}"
echo "Deploy helper - will copy config examples and show manual steps."
mkdir -p "$ROOT/out_deploy"
cp -a deploy/systemd/*.service "$ROOT/out_deploy/" 2>/dev/null || true
cp -a deploy/nginx/*.conf "$ROOT/out_deploy/" 2>/dev/null || true
cp -a deploy/*.yml "$ROOT/out_deploy/" 2>/dev/null || true
cat > "$ROOT/out_deploy/etc_ai_agent_env_example" <<'ENV'
OPENAI_API_KEY=sk-REPLACE_ME
AI_DEFAULT_MODEL=gpt-4o-mini
ENV
echo "Created out_deploy/ with example files. Next manual steps:"
echo " - Review files in $ROOT/out_deploy"
echo " - Copy systemd units to /etc/systemd/system/ and reload daemon"
echo " - Copy nginx conf to /etc/nginx/sites-available/ and enable it"
echo " - Secure /etc/ai-agent/env and restart services"
