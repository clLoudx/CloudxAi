#!/usr/bin/env bash
# apply_patch.sh - apply aiagent_release.patch to current repo using git am (safe wrapper)
set -euo pipefail
PATCH="$1"
if [ -z "$PATCH" ]; then
  echo "Usage: $0 path/to/aiagent_release.patch"
  exit 2
fi
git status --porcelain
git apply --stat "$PATCH"
git apply --check "$PATCH"
git checkout -b patch/apply-aiagent-release-$(date +%s)
git am --signoff "$PATCH" || { echo "git am failed; aborting"; git am --abort; exit 1; }
echo "Patch applied to branch $(git rev-parse --abbrev-ref HEAD)"
