#!/usr/bin/env bash
set -euo pipefail
if [ -z "${1-}" ]; then
  echo "Usage: $0 <path-to-repo-archive.zip|tar.gz> [target_dir]"
  exit 1
fi
ARCHIVE="$1"
TARGET="${2:-repo}"
if [ -d "$TARGET" ]; then
  mv "$TARGET" "${TARGET}_backup_$(date +%s)"
fi
mkdir -p "$TARGET"
if [[ "$ARCHIVE" == *.zip ]]; then
  unzip -q "$ARCHIVE" -d "$TARGET"
else
  tar -xzf "$ARCHIVE" -C "$TARGET"
fi
echo "Imported into $TARGET"
