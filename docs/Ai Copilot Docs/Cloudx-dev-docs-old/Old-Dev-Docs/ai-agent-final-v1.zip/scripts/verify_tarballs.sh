#!/usr/bin/env bash
# verify_tarballs.sh - compute and print sha256 sums for exported docker tarballs
set -euo pipefail
DIR="${1:-export_images}"
if [ ! -d "$DIR" ]; then
  echo "Directory $DIR not found. Run build_and_export.sh first."
  exit 1
fi
echo "SHA256 sums for $DIR:"
sha256sum "$DIR"/* | tee sha256_export_images.txt
echo "Saved to sha256_export_images.txt"
