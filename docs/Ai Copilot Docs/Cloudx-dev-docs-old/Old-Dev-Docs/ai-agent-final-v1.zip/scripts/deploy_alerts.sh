#!/usr/bin/env bash
# deploy_alerts.sh - copy generated alert rules to Prometheus rules dir and reload
set -euo pipefail
SRC="deploy/alert_rules_generated.yml"
DST_DIR="/etc/prometheus/rules"
DST="$DST_DIR/ai-agent-alerts.yml"

if [ ! -f "$SRC" ]; then
  echo "Source $SRC not found! Run this from repo root."
  exit 1
fi

sudo mkdir -p "$DST_DIR"
sudo cp "$SRC" "$DST"
echo "Copied $SRC -> $DST"
echo "Reloading Prometheus..."
if command -v systemctl >/dev/null 2>&1; then
  sudo systemctl reload prometheus || sudo systemctl restart prometheus
else
  echo "systemctl not found. Please reload Prometheus manually."
fi
echo "Done."
