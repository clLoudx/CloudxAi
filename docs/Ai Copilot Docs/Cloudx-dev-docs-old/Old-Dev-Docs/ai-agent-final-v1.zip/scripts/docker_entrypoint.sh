#!/usr/bin/env bash
set -euo pipefail
ROLE=${ROLE:-dashboard}
if [ "$ROLE" = "dashboard" ]; then
  exec /opt/ai-agent/venv/bin/gunicorn -k eventlet -w 1 -b 0.0.0.0:8099 app:app -C /opt/ai-agent/gunicorn.conf.py
elif [ "$ROLE" = "worker" ]; then
  exec /opt/ai-agent/venv/bin/python worker/worker.py
else
  echo "Unknown ROLE: $ROLE"
  exit 2
fi
