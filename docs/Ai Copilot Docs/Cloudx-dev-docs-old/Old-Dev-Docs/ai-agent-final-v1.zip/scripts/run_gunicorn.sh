#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
VENV="${ROOT_DIR}/venv"
if [ ! -d "$VENV" ]; then
  echo "Virtualenv not found at $VENV. Create with: python3 -m venv $VENV && $VENV/bin/pip install -r requirements.txt"
  exit 1
fi
exec "$VENV/bin/gunicorn" -k eventlet -w 1 -b 127.0.0.1:8099 app:app
