# worker/worker.py (Redis-backed if REDIS_URL provided, else filesystem fallback)
import os, time, json, logging
from pathlib import Path

try:
    import redis
except Exception:
    redis = None

TASK_DIR = Path(os.getenv('AI_TASK_DIR', '/tmp/ai_tasks'))
HEARTBEAT = Path(os.getenv('AI_HEARTBEAT_FILE', '/tmp/ai_worker_heartbeat'))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('ai.worker')

TASK_DIR.mkdir(parents=True, exist_ok=True)

# prometheus metrics (import-safe if prometheus_client available)
try:
    from prometheus_client import Gauge, Histogram
    QUEUE_GAUGE = Gauge('ai_queue_tasks', 'Number of tasks in queue')
    TASK_LATENCY = Histogram('ai_task_latency_seconds', 'Task processing latency seconds', buckets=(0.01,0.05,0.1,0.25,0.5,1,2,5,10))
    WORKER_HEARTBEAT = Gauge('ai_worker_last_heartbeat', 'Timestamp of last worker heartbeat')
except Exception:
    QUEUE_GAUGE = None
    TASK_LATENCY = None
    WORKER_HEARTBEAT = None

REDIS_URL = os.getenv('REDIS_URL', None)
def get_redis():
    if not REDIS_URL or not redis:
        return None
    try:
        return redis.from_url(REDIS_URL, decode_responses=True)
    except Exception as e:
        logger.warning('redis connect failed: %s', e)
        return None

def heartbeat():
    HEARTBEAT.write_text(str(time.time()))
    if WORKER_HEARTBEAT:
        WORKER_HEARTBEAT.set(time.time())

def update_queue_gauge(rc=None):
    if rc:
        try:
            l = rc.llen('ai_tasks')
            if QUEUE_GAUGE:
                QUEUE_GAUGE.set(l)
            return l
        except Exception:
            pass
    # fallback filesystem
    files = list(TASK_DIR.glob('*.json'))
    if QUEUE_GAUGE:
        try:
            QUEUE_GAUGE.set(len(files))
        except Exception:
            pass
    return len(files)

def process_task_obj(obj):
    start = time.time()
    try:
        # simulate processing:
        logger.info('Processing task: %s', obj.get('task_id'))
        time.sleep(1)
        # mark done actions here (e.g., store results)
        duration = time.time() - start
        if TASK_LATENCY:
            try:
                TASK_LATENCY.observe(duration)
            except Exception:
                pass
    except Exception as e:
        logger.exception('Task processing failed: %s', e)

def consume_filesystem():
    for p in sorted(TASK_DIR.glob('*.json')):
        try:
            data = json.loads(p.read_text())
            process_task_obj(data)
            (p.with_suffix('.done')).write_text('ok')
            p.unlink()
        except Exception as e:
            logger.exception('Failed processing %s: %s', p, e)

def main():
    rc = get_redis()
    logger.info('Worker starting (redis=%s)', bool(rc))
    while True:
        heartbeat()
        if rc:
            try:
                # blocking pop with timeout to allow heartbeat updates
                item = rc.brpop('ai_tasks', timeout=5)
                update_queue_gauge(rc=rc)
                if item:
                    # brpop returns (list_name, item)
                    payload = item[1]
                    obj = json.loads(payload)
                    process_task_obj(obj)
            except Exception as e:
                logger.exception('Redis pop failed: %s', e)
                time.sleep(1)
        else:
            update_queue_gauge()
            consume_filesystem()
            time.sleep(2)

if __name__ == '__main__':
    main()
