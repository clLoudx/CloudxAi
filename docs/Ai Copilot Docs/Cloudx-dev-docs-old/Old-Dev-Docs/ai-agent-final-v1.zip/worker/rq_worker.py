# worker/rq_worker.py - RQ worker job functions with DLQ handling
import logging, time, json, os
logger = logging.getLogger('worker.rq')

try:
    import redis
except Exception:
    redis = None

REDIS_URL = os.getenv('REDIS_URL', None)

def _push_to_dlq(entry):
    try:
        if not redis or not REDIS_URL:
            logger.warning('DLQ not available (redis or REDIS_URL missing)')
            return False
        rc = redis.from_url(REDIS_URL, decode_responses=True)
        rc.lpush('ai_tasks_dlq', json.dumps(entry))
        logger.info('Pushed job to DLQ: %s', entry.get('job_id'))
        return True
    except Exception as e:
        logger.exception('Failed to push to DLQ: %s', e)
        return False

def rq_process_task(task):
    """Process a single task (called by RQ). Exceptions are caught and recorded to DLQ."""
    job_id = task.get('task_id', f'rq-{int(time.time())}')
    try:
        logger.info('RQ processing task %s', job_id)
        # --- Place your real processing logic here ---
        # Example: echo payload or call ai.adapter
        # Simulate work:
        time.sleep(1)
        # If you want to call adapter: from ai.adapter import call_openai
        # resp = call_openai([{'role':'user','content': task.get('payload', {}).get('text','')}])
        # store result somewhere, etc.
        return {'status':'done','task_id':job_id}
    except Exception as e:
        logger.exception('Task failed: %s', e)
        entry = {'job_id': job_id, 'payload': task, 'error': str(e), 'time': time.time()}
        _push_to_dlq(entry)
        # re-raise so RQ may record failure as well if desired
        raise
