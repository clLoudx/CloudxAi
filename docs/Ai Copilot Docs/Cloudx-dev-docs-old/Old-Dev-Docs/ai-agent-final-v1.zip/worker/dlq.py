# worker/dlq.py - helper to inspect/move DLQ entries
import os, json, logging, time
try:
    import redis
except Exception:
    redis = None
logger = logging.getLogger('worker.dlq')
def list_dlq(limit=100):
    if not redis or not os.getenv('REDIS_URL'):
        return []
    rc = redis.from_url(os.getenv('REDIS_URL'))
    items = rc.lrange('ai_tasks_dlq', 0, limit-1)
    return [json.loads(i) for i in items]
def requeue_one():
    if not redis or not os.getenv('REDIS_URL'):
        return None
    rc = redis.from_url(os.getenv('REDIS_URL'))
    item = rc.rpop('ai_tasks_dlq')
    if not item:
        return None
    entry = json.loads(item)
    payload = entry.get('payload') or {}
    rc.lpush('ai_tasks', json.dumps(payload))
    return entry
