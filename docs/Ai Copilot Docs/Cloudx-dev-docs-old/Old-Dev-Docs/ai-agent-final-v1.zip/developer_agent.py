#!/usr/bin/env python3
import os, json, subprocess, sys
from queue_client import QueueClient
qc = QueueClient()

def analyze_and_create_tasks(repo_path=None):
    repo = repo_path or os.getenv('REPO_PATH','./repo')
    print('Analyzing repo at', repo)
    try:
        out = subprocess.check_output(['python3','analyze_project.py'], env={**os.environ, 'REPO_PATH': repo})
        report = json.loads(out.decode())
    except Exception as e:
        print('Analysis failed', e); report = {}
    php_count = report.get('by_extension',{}).get('.php',0)
    # create one dev task and one debug monitoring task
    if php_count > 0:
        qc.push_task({'task_id':'dev-'+str(abs(hash(repo)))[:8], 'mode':'build', 'instructions':'Implement tests and improve code quality', 'queue':'tasks'}, queue='tasks')
        qc.push_task({'task_id':'dbg-'+str(abs(hash(repo)))[:8], 'mode':'monitor', 'instructions':'Run continuous debug monitoring and create fix tasks on failures', 'queue':'debug'}, queue='debug')
        print('Created dev and debug tasks for', repo)
    else:
        print('No PHP files detected; nothing queued')

if __name__=='__main__':
    repo = sys.argv[1] if len(sys.argv)>1 else None
    analyze_and_create_tasks(repo)
