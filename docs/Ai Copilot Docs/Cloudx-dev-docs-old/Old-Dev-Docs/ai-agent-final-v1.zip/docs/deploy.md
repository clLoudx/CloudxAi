# Deploy Instructions (summary)

1. Copy systemd units under /etc/systemd/system/
2. Create /etc/ai-agent/env with secure permissions (600) and add OPENAI_API_KEY (do not commit)
3. Copy nginx conf to /etc/nginx/sites-available/ and enable it
4. Reload systemd and start services
