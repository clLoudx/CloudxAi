#!/bin/bash
# usage: ./terminate_worker.sh <worker-name-substring>
if [ -z "$1" ]; then echo "usage: $0 <worker-name-substring>"; exit 1; fi
pkill -f "$1" || echo "no process matched $1"
