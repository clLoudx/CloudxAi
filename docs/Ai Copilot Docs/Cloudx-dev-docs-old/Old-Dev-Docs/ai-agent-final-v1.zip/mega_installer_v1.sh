#!/usr/bin/env bash
# mega_installer_v1.sh - Enterprise, idempotent installer for AI Agent v1
# Usage (recommended: test in staging):
# sudo ./mega_installer_v1.sh --target-dir /opt/ai-agent --domain your.domain.tld --deploy-tls yes
set -euo pipefail

#######################
# Configuration flags #
#######################
TARGET_DIR="/opt/aiagent"
DOMAIN=""
DEPLOY_TLS="no"     # yes|no
INSTALL_DOCKER="no"  # yes|no - set to yes to install Docker if missing
GIT_APPLY_PATCH="yes" # apply aiagent_release.patch if present in current dir
PROMetheus_RULES_SRC="deploy/alert_rules_generated.yml"
GRAFANA_DASHBOARDS_DIR="deploy/grafana/dashboards"
EXPORT_IMAGES_DIR="${TARGET_DIR}/export_images"
AI_USER="aiagent"
ENV_DIR="/etc/ai-agent"
ENV_FILE="${ENV_DIR}/env"
SYSTEMD_DIR="/etc/systemd/system"
NGINX_SITE="/etc/nginx/sites-available/ai-agent.conf"
MAKE_BACKUPS="yes"

####################
# Helper functions #
####################
log() { echo "==> $*"; }
err() { echo "ERROR: $*" >&2; exit 1; }
backup_if_exists() {
  local p="$1"
  if [ -e "$p" ] && [ "${MAKE_BACKUPS}" = "yes" ]; then
    local ts
    ts=$(date +%Y%m%d_%H%M%S)
    sudo cp -a "$p" "${p}.bak.$ts"
    log "Backed up $p to ${p}.bak.$ts"
  fi
}

usage() {
  cat <<EOF
mega_installer_v1.sh - install AI Agent v1
Options:
  --target-dir <path>      Directory to install project (default: /opt/ai-agent)
  --domain <domain>        Domain name for nginx/Certbot (optional)
  --deploy-tls <yes|no>    Whether to request TLS certs via certbot (default: no)
  --install-docker <yes|no> Install Docker if missing (default: no)
  --skip-git-patch         Skip applying aiagent_release.patch
  -h|--help                Show this message
EOF
  exit 0
}

# parse args
while [ $# -gt 0 ]; do
  case "$1" in
    --target-dir) TARGET_DIR="$2"; shift 2;;
    --domain) DOMAIN="$2"; shift 2;;
    --deploy-tls) DEPLOY_TLS="$2"; shift 2;;
    --install-docker) INSTALL_DOCKER="$2"; shift 2;;
    --skip-git-patch) GIT_APPLY_PATCH="no"; shift 1;;
    -h|--help) usage;;
    *) echo "Unknown arg: $1"; usage;;
  esac
done

##########################
# Preconditions & checks #
##########################
if [ "$(id -u)" -ne 0 ]; then
  err "This installer must be run as root (or via sudo). Exiting."
fi

log "Install starting. Target dir: ${TARGET_DIR}. Domain: ${DOMAIN}. TLS: ${DEPLOY_TLS}. Install Docker if missing: ${INSTALL_DOCKER}"

# Create ai user if missing
if ! id -u "${AI_USER}" >/dev/null 2>&1; then
  log "Creating system user ${AI_USER}"
  useradd --system --create-home --home-dir /home/"${AI_USER}" --shell /usr/sbin/nologin "${AI_USER}"
fi

# Ensure target dir exists and copy files (if script run from repo root)
mkdir -p "${TARGET_DIR}"
log "Copying project files to ${TARGET_DIR} (safe copy)"
rsync -a --delete --exclude='.git' ./ "${TARGET_DIR}/"

# Set ownership
chown -R "${AI_USER}:${AI_USER}" "${TARGET_DIR}"

# Create /etc/ai-agent and env file template
mkdir -p "${ENV_DIR}"
chmod 750 "${ENV_DIR}"
if [ ! -f "${ENV_FILE}" ]; then
  cat > "${ENV_FILE}" <<'ENV'
# /etc/ai-agent/env - required secrets (edit and secure)
# Example:
# OPENAI_API_KEY=sk-xxxx
# API_KEY=replace-with-admin-api-key
# REDIS_URL=redis://127.0.0.1:6379/0
# AI_TASK_DIR=/tmp/ai_tasks
# FLASK_SECRET=replace-with-long-random
ENV
  chmod 600 "${ENV_FILE}"
  chown root:root "${ENV_FILE}"
  log "Created template env file at ${ENV_FILE}. Edit it with secrets and secure permissions (600)."
else
  log "Env file ${ENV_FILE} already exists - leaving in place"
fi

# Optionally install Docker
if [ "${INSTALL_DOCKER}" = "yes" ]; then
  if ! command -v docker >/dev/null 2>&1; then
    log "Installing Docker (apt-get)"
    apt-get update
    apt-get install -y       ca-certificates curl gnupg lsb-release
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    echo       "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu       $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
    log "Docker installed. Adding ${AI_USER} to docker group."
    usermod -aG docker "${AI_USER}" || true
  else
    log "Docker already present"
  fi
fi

# Build/export Docker images (if Docker available)
mkdir -p "${EXPORT_IMAGES_DIR}"
if command -v docker >/dev/null 2>&1; then
  log "Building Docker images (this may take a while)..."
  cd "${TARGET_DIR}"
  if [ -f Dockerfile ]; then
    docker build -f Dockerfile -t aiagent_web:latest "${TARGET_DIR}"
  else
    log "No Dockerfile found in ${TARGET_DIR}; skipping image build"
  fi
  if [ -f Dockerfile.worker ]; then
    docker build -f Dockerfile.worker -t aiagent_worker:latest "${TARGET_DIR}"
  fi
  # Save images to tarballs
  if docker image inspect aiagent_web:latest >/dev/null 2>&1; then
    docker save aiagent_web:latest | gzip > "${EXPORT_IMAGES_DIR}/aiagent_web_latest.tar.gz"
  fi
  if docker image inspect aiagent_worker:latest >/dev/null 2>&1; then
    docker save aiagent_worker:latest | gzip > "${EXPORT_IMAGES_DIR}/aiagent_worker_latest.tar.gz"
  fi
  sha256sum "${EXPORT_IMAGES_DIR}"/* > "${EXPORT_IMAGES_DIR}/sha256_export_images.txt" || true
  log "Docker images built/exported to ${EXPORT_IMAGES_DIR}"
else
  log "Docker not available on this host; skipping image build. Use scripts/build_and_export.sh on a Docker host to build images."
fi

# Apply git patch if present and allowed
if [ "${GIT_APPLY_PATCH}" = "yes" ] && [ -f "${TARGET_DIR}/aiagent_release.patch" ]; then
  log "Attempting to apply git patch ${TARGET_DIR}/aiagent_release.patch"
  # only attempt apply if we have a git repo here
  if [ -d "${TARGET_DIR}/.git" ]; then
    cd "${TARGET_DIR}"
    git apply --stat aiagent_release.patch
    git apply --check aiagent_release.patch
    git checkout -b "patch/apply-aiagent-release-$(date +%s)"
    if git am --signoff aiagent_release.patch; then
      log "Patch applied successfully"
    else
      log "git am failed; trying 3-way apply"
      git am --abort || true
      git apply --3way aiagent_release.patch || true
      log "Patch applied with 3-way merge; please inspect files and commit manually if needed."
    fi
  else
    log "No .git in ${TARGET_DIR}; skipping patch apply"
  fi
fi

#########################
# Systemd unit templates
#########################
log "Writing systemd unit files (app + worker) to ${SYSTEMD_DIR}"
# app service (gunicorn via run_gunicorn.sh)
APP_SERVICE="${SYSTEMD_DIR}/aiagent-app.service"
backup_if_exists "${APP_SERVICE}"
cat > /tmp/aiagent-app.service <<'UNIT'
[Unit]
Description=AI Agent Dashboard (Gunicorn)
After=network.target
Requires=network.target

[Service]
Type=simple
User=aiagent
Group=aiagent
WorkingDirectory=/opt/ai-agent/dashboard
EnvironmentFile=/etc/ai-agent/env
ExecStart=/usr/bin/env bash -lc "source /opt/ai-agent/venv/bin/activate || true; exec gunicorn dashboard.app:app -k eventlet -b 0.0.0.0:8000 --workers 3"
Restart=on-failure
RestartSec=5
LimitNOFILE=4096

[Install]
WantedBy=multi-user.target
UNIT
sudo mv /tmp/aiagent-app.service "${APP_SERVICE}"
chmod 644 "${APP_SERVICE}"

# worker service (RQ worker)
WORKER_SERVICE="${SYSTEMD_DIR}/aiagent-rq.service"
backup_if_exists "${WORKER_SERVICE}"
cat > /tmp/aiagent-rq.service <<'UNIT'
[Unit]
Description=AI Agent RQ Worker
After=network.target
Requires=network.target

[Service]
Type=simple
User=aiagent
Group=aiagent
WorkingDirectory=/opt/ai-agent
EnvironmentFile=/etc/ai-agent/env
ExecStart=/usr/bin/env bash -lc "source /opt/ai-agent/venv/bin/activate || true; exec rq worker -u ${REDIS_URL:-redis://127.0.0.1:6379/0} default"
Restart=on-failure
RestartSec=5
LimitNOFILE=4096

[Install]
WantedBy=multi-user.target
UNIT
sudo mv /tmp/aiagent-rq.service "${WORKER_SERVICE}"
chmod 644 "${WORKER_SERVICE}"

# reload systemd
log "Reloading systemd daemon"
systemctl daemon-reload || true

# Enable services but do not start them automatically unless user confirms
log "Enabling aiagent-app and aiagent-rq services"
systemctl enable aiagent-app.service || true
systemctl enable aiagent-rq.service || true

##################################
# Nginx config (reverse proxy)
##################################
if command -v nginx >/dev/null 2>&1; then
  backup_if_exists "${NGINX_SITE}"
  cat > /tmp/ai-agent-nginx.conf <<'NGINX'
server {
  listen 80;
  server_name DOMAIN_PLACEHOLDER;

  location / {
    proxy_pass http://127.0.0.1:8000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection "upgrade";
  }

  location /static/ {
    alias /opt/ai-agent/dashboard/static/;
  }

  location /metrics {
    allow 127.0.0.1;
    # allow PROMETHEUS_IP;
    deny all;
    proxy_pass http://127.0.0.1:8000/metrics;
  }
}
NGINX
  sed "s/DOMAIN_PLACEHOLDER/${DOMAIN:-_}/g" /tmp/ai-agent-nginx.conf > /tmp/ai-agent-nginx.conf.out
  mv /tmp/ai-agent-nginx.conf.out "${NGINX_SITE}"
  chmod 644 "${NGINX_SITE}"
  ln -sf "${NGINX_SITE}" /etc/nginx/sites-enabled/ai-agent.conf
  log "Reloading nginx"
  nginx -t && systemctl reload nginx || log "nginx config test failed or reload failed - check manually"
else
  log "nginx not installed; skipping nginx configuration. You can add reverse-proxy later using ${NGINX_SITE} template."
fi

##################################
# Prometheus rules & Grafana provisioning
##################################
if [ -f "${TARGET_DIR}/${PROMetheus_RULES_SRC}" ]; then
  sudo mkdir -p /etc/prometheus/rules
  backup_if_exists /etc/prometheus/rules/ai-agent-alerts.yml
  sudo cp "${TARGET_DIR}/${PROMetheus_RULES_SRC}" /etc/prometheus/rules/ai-agent-alerts.yml
  log "Copied Prometheus rules to /etc/prometheus/rules/ai-agent-alerts.yml"
  if command -v systemctl >/dev/null 2>&1; then
    systemctl reload prometheus || systemctl restart prometheus || log "Prometheus reload failed; please restart Prometheus manually"
  fi
else
  log "Prometheus rules source not found: ${TARGET_DIR}/${PROMetheus_RULES_SRC}"
fi

# Grafana provisioning
if [ -d "${TARGET_DIR}/${GRAFANA_DASHBOARDS_DIR}" ]; then
  GRAFANA_PROV_DIR="/etc/grafana/provisioning/dashboards/ai-agent"
  sudo mkdir -p "${GRAFANA_PROV_DIR}"
  backup_if_exists "${GRAFANA_PROV_DIR}"
  sudo cp -a "${TARGET_DIR}/${GRAFANA_DASHBOARDS_DIR}/." "${GRAFANA_PROV_DIR}/" || true
  log "Copied Grafana dashboards to ${GRAFANA_PROV_DIR} (ensure Grafana provisioning YAML points to this directory)"
else
  log "Grafana dashboards dir not found at ${TARGET_DIR}/${GRAFANA_DASHBOARDS_DIR}"
fi

#####################
# Virtualenv (venv) #
#####################
log "Ensuring Python venv and dependencies"
if [ ! -d "${TARGET_DIR}/venv" ]; then
  python3 -m venv "${TARGET_DIR}/venv"
fi
# activate and pip install
# Use pip only if requirements exist
if [ -f "${TARGET_DIR}/requirements.txt" ]; then
  log "Installing Python dependencies from requirements.txt"
  # Use pip in venv
  "${TARGET_DIR}/venv/bin/pip" install --upgrade pip
  "${TARGET_DIR}/venv/bin/pip" install -r "${TARGET_DIR}/requirements.txt"
else
  log "No requirements.txt found; skipping pip install"
fi

####################
# Final start step #
####################
log "All artifacts prepared. Next steps:"
echo "  1) Review /etc/ai-agent/env and populate secrets (OPENAI_API_KEY, API_KEY, REDIS_URL, FLASK_SECRET)"
echo "  2) If you want systemd-managed services, start them now:"
echo "       sudo systemctl start aiagent-app.aiagent-app.service || sudo systemctl start aiagent-app"
echo "       sudo systemctl start aiagent-rq.service || sudo systemctl start aiagent-rq"
echo "  3) If you prefer Docker Compose, call docker compose up -d from ${TARGET_DIR}"
echo "  4) Check logs: sudo journalctl -u aiagent-app -f and sudo journalctl -u aiagent-rq -f"
echo "  5) Open the DLQ UI: http://<host>/dlq  (auth via API_KEY or session login)"

# print verification commands
cat <<EOF
VERIFICATION STEPS:
- Check app health: curl -s http://127.0.0.1:8000/api/overview
- Check metrics: curl -s http://127.0.0.1:8000/metrics | head
- Check worker: rq info -u ${REDIS_URL:-redis://127.0.0.1:6379/0}
- Check DLQ depth (redis): redis-cli -u ${REDIS_URL:-redis://127.0.0.1:6379/0} LLEN ai_tasks_dlq

Rollback plan summary:
- Stop services: sudo systemctl stop aiagent-app aiagent-rq
- Restore backup files (.bak.*) in /etc/nginx/sites-available or systemd if created
- Replace /opt/ai-agent with backup from your out_deploy/backups/ or git
EOF

log "MEGA INSTALLER completed. Review the previous messages for additional manual steps (Certbot, DNS)."
