#!/usr/bin/env bash
set -euo pipefail
source venv/bin/activate
docker-compose up -d
# start coordinator
nohup python3 coordinator.py >> logs/coordinator.log 2>&1 &
# start workers for dev and debug queues
nohup WORKER_NAME=dev-worker-1 WORKER_SKILLS="php,db" python3 worker.py tasks >> logs/worker_dev1.log 2>&1 &
nohup WORKER_NAME=dev-worker-2 WORKER_SKILLS="php" python3 worker.py tasks >> logs/worker_dev2.log 2>&1 &
nohup WORKER_NAME=debug-worker-1 WORKER_SKILLS="fix" python3 worker.py debug >> logs/worker_debug1.log 2>&1 &
nohup python3 verifier.py >> logs/verifier.log 2>&1 &
nohup python3 patcher.py >> logs/patcher.log 2>&1 &
nohup python3 autofix.py >> logs/autofix.log 2>&1 &
nohup python3 dashboard/app.py >> logs/dashboard.log 2>&1 &
nohup python3 developer_agent.py >> logs/developer_agent.log 2>&1 &
echo "Agent started - check logs/"
