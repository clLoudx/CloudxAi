#!/usr/bin/env bash
set -euo pipefail
source venv/bin/activate
# ensure docker redis running
docker-compose up -d redis
# start coordinator and a single mock worker in foreground for demo
python3 coordinator.py &
MOCK_MODE=true WORKER_NAME=demo-worker python3 worker.py tasks &
# wait and then show queues
sleep 2
python3 - <<'PY'
from queue_client import QueueClient
q=QueueClient()
print('tasks_len=', q.r.llen('ai:tasks'))
print('results_len=', q.r.llen('ai:results'))
PY
