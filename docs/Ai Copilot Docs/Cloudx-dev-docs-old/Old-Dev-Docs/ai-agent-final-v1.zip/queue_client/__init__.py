# queue_client package - provides QueueClient class for tests
import os, json, time
from pathlib import Path

class QueueClient:
    def __init__(self, base='/tmp/ai_tasks'):
        self.base = Path(base)
        self.tasks_dir = self.base / 'tasks'
        self.ops_file = self.base / 'operations.jsonl'
        self.tasks_dir.mkdir(parents=True, exist_ok=True)
        self.ops_file.parent.mkdir(parents=True, exist_ok=True)
        if not self.ops_file.exists():
            self.ops_file.write_text('')

    def push_task(self, task: dict, queue: str = 'tasks'):
        p = self.tasks_dir / (str(time.time()).replace('.','_') + '_' + task.get('task_id','task') + '.json')
        p.write_text(json.dumps(task))
        return str(p)

    def reserve_task(self, queue: str = 'tasks'):
        files = sorted(self.tasks_dir.glob('*.json'))
        if not files:
            return None
        p = files[0]
        data = json.loads(p.read_text())
        # mark reserved by moving file to .reserved (simulate)
        reserved = p.with_suffix('.reserved')
        p.rename(reserved)
        return data

    def log_operation(self, name, objid, payload):
        line = json.dumps({'time': time.time(), 'name': name, 'id': objid, 'payload': payload})
        with open(self.ops_file, 'a') as fh:
            fh.write(line + '\n')
        return True

    def get_operations(self, limit=10):
        if not self.ops_file.exists():
            return []
        lines = self.ops_file.read_text().strip().splitlines()[-limit:]
        return [json.loads(l) for l in lines if l.strip()]
