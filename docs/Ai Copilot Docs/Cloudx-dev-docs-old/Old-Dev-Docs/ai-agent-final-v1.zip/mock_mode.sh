#!/bin/bash
export MOCK_MODE=true
./run_agent.sh
