#!/usr/bin/env python3
import os, json, time, uuid
from dotenv import load_dotenv
from queue_client import QueueClient
from datetime import datetime

load_dotenv()
qc = QueueClient()
CONF_THRESH = float(os.getenv('CONFIDENCE_THRESHOLD','0.85'))
AUTO_MERGE = os.getenv('AUTO_MERGE','false').lower() in ('1','true','yes')

PRINCIPAL_PROMPT = open('prompts/coordinator_prompt.txt','r').read()

class Coordinator:
    def __init__(self):
        self.q = qc

    def create_task(self, mode: str, instructions: str, queue='tasks', files_snapshot=None, constraints=None):
        task = {
            'task_id': str(uuid.uuid4()),
            'mode': mode,
            'instructions': instructions,
            'queue': queue,
            'files_snapshot': files_snapshot or {},
            'constraints': constraints or {},
            'created_at': datetime.utcnow().isoformat()
        }
        self.q.push_task(task, queue=queue)
        print('Task queued:', task['task_id'], 'queue=', queue)
        return task['task_id']

    def handle_result(self, res: dict):
        tid = res.get('task_id')
        print('\n[Coordinator] Result for', tid)
        conf = float(res.get('confidence',0))
        requires_review = bool(res.get('requires_review', False))
        # route apply or debug based on confidence
        if conf >= CONF_THRESH and not requires_review:
            print('[Coordinator] High confidence -> apply')
            self.q.push_apply(res)
        else:
            print('[Coordinator] Low confidence or review needed -> route to debug queue and alert human')
            # route to debug queue
            self.q.push_task({'task_id': tid, 'mode':'fix', 'instructions': 'Auto-fix: investigate low confidence result', 'origin_result': res}, queue='debug')
            # notify via alerts queue
            alert = {'id': str(uuid.uuid4()), 'task_id': tid, 'level':'warning', 'message':'Low confidence result needs review', 'time': datetime.utcnow().isoformat()}
            self.q.push_alert(alert)

    def run_loop(self):
        print('Coordinator running - monitoring results and alerts')
        while True:
            res = self.q.pop_result()
            if res:
                self.handle_result(res)
            alert = self.q.pop_alert()
            if alert:
                print('[Coordinator] Received alert:', alert)
            time.sleep(0.8)

if __name__ == '__main__':
    import sys
    c = Coordinator()
    if len(sys.argv) > 1 and sys.argv[1] == 'create':
        queue = sys.argv[2]
        mode = sys.argv[3]
        instr = ' '.join(sys.argv[4:])
        c.create_task(mode, instr, queue=queue)
    else:
        c.run_loop()
