#!/usr/bin/env python3
import os, json, re
from pathlib import Path
from collections import defaultdict

REPO = os.getenv('REPO_PATH','./repo')

def scan_files():
    tree = []
    for p in Path(REPO).rglob('*'):
        if p.is_file():
            tree.append(str(p.relative_to(REPO)))
    return tree

def scan_sql():
    sql_files = list(Path(REPO).rglob('*.sql'))
    schemas = {}
    for sf in sql_files:
        with open(sf, 'r', encoding='utf-8', errors='ignore') as f:
            data = f.read()
        tables = re.findall(r'CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?[`\']?(\w+)[`\']?', data, flags=re.I)
        schemas[str(sf.relative_to(REPO))] = tables
    return schemas

def analyze():
    files = scan_files()
    sql = scan_sql()
    stats = defaultdict(int)
    for f in files:
        ext = os.path.splitext(f)[1].lower()
        stats[ext]+=1
    report = {
        'total_files': len(files),
        'by_extension': stats,
        'sql_tables': sql
    }
    print(json.dumps(report, indent=2))

if __name__=='__main__':
    analyze()
