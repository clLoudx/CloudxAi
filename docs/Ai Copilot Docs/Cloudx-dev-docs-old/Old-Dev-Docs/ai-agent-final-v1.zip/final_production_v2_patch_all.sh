#!/usr/bin/env bash
set -euo pipefail

echo 'Applying final_production_v2_patch_all (non-destructive)'

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/ai/adapter.py" ]; then echo "SKIP exists: ai/adapter.py"; else echo "WRITE: ai/adapter.py"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/ai"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/ai/adapter.py" <<'PYFILE'
# ai/adapter.py (production-ready)
import os, requests, time, json, logging
from typing import List, Dict

logger = logging.getLogger("ai.adapter")
DEFAULT_MODEL = os.getenv("AI_DEFAULT_MODEL", "gpt-4o-mini")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
REQUEST_TIMEOUT = int(os.getenv("AI_REQUEST_TIMEOUT", "20"))
BLACKLIST = [
    'rm -rf', 'shutdown', 'reboot', 'passwd', '/etc/shadow',
    'import os', 'eval(', 'exec(', 'open(/etc'
]

def is_safe(text: str) -> bool:
    t = text.lower()
    for b in BLACKLIST:
        if b in t:
            return False
    return True

def call_openai(messages: List[Dict], model: str = DEFAULT_MODEL, api_key: str = None, timeout: int = REQUEST_TIMEOUT):
    key = api_key or OPENAI_API_KEY
    last = messages[-1]['content'] if messages else ''
    if not is_safe(last):
        return {"error": "blocked", "reply": "[blocked - unsafe content]"}
    if not key:
        # deterministic mock: echo + stable token
        return {"mock": True, "reply": "[MOCK] " + last}
    url = "https://api.openai.com/v1/chat/completions"
    headers = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    payload = {"model": model, "messages": messages, "temperature": 0.2}
    backoff = 1
    for attempt in range(3):
        try:
            r = requests.post(url, headers=headers, json=payload, timeout=timeout)
            r.raise_for_status()
            body = r.json()
            choice = body.get('choices', [{}])[0]
            msg = choice.get('message') or choice.get('text') or {}
            content = msg.get('content') if isinstance(msg, dict) else str(msg)
            return {"mock": False, "reply": content, "meta": {"usage": body.get("usage")}} 
        except Exception as e:
            logger.warning("OpenAI attempt %s failed: %s", attempt+1, e)
            time.sleep(backoff)
            backoff *= 2
    return {"error": "openai_failed", "reply": "[MOCK-FALLBACK] " + last}

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/static/js/dashboard.js" ]; then echo "SKIP exists: dashboard/static/js/dashboard.js"; else echo "WRITE: dashboard/static/js/dashboard.js"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/static/js"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/static/js/dashboard.js" <<'PYFILE'
// dashboard/static/js/dashboard.js
// Minimal production-ready frontend JS: SocketIO + fetch fallbacks + UI hooks
document.addEventListener('DOMContentLoaded', function () {
  const chatForm = document.getElementById('chat-form');
  const chatInput = document.getElementById('chat-input');
  const chatOut = document.getElementById('chat-out');
  if (chatForm) {
    chatForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const text = chatInput.value;
      if (!text) return;
      appendMsg('you', text);
      chatInput.value = '';
      try {
        const res = await fetch('/api/chat', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text})});
        const j = await res.json();
        appendMsg('ai', j.reply || JSON.stringify(j));
      } catch (err) {
        appendMsg('ai','[error] ' + err.message);
      }
    }, false);
  }
  function appendMsg(who, text) {
    if (!chatOut) return;
    const el = document.createElement('div');
    el.className = 'msg ' + who;
    el.textContent = (who === 'you' ? 'You: ' : 'AI: ') + text;
    chatOut.appendChild(el);
    chatOut.scrollTop = chatOut.scrollHeight;
  }
  // try socket.io
  if (window.io) {
    try {
      const socket = io();
      socket.on('connect', () => console.log('socket connected'));
      socket.on('task_done', (data) => {
        appendMsg('ai', '[task_done] ' + JSON.stringify(data));
      });
    } catch(e) { console.warn('Socket init failed', e); }
  }
});

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/templates/index.html" ]; then echo "SKIP exists: dashboard/templates/index.html"; else echo "WRITE: dashboard/templates/index.html"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/templates"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/templates/index.html" <<'PYFILE'
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>AI Agent Dashboard</title>
  <link rel="stylesheet" href="/static/css/dashboard.css">
  <script src="/static/js/dashboard.js" defer></script>
  <script src="/socket.io/socket.io.js" defer></script>
</head>
<body>
  <main class="container">
    <h1>AI Agent Dashboard</h1>
    <section id="chat">
      <div id="chat-out" class="chat-out" style="height:300px; overflow:auto; border:1px solid #ccc; padding:8px;"></div>
      <form id="chat-form">
        <input id="chat-input" placeholder="Say hello" autocomplete="off"/>
        <button type="submit">Send</button>
      </form>
    </section>
  </main>
</body>
</html>

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/static/css/dashboard.css" ]; then echo "SKIP exists: dashboard/static/css/dashboard.css"; else echo "WRITE: dashboard/static/css/dashboard.css"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/static/css"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/dashboard/static/css/dashboard.css" <<'PYFILE'
/* dashboard/static/css/dashboard.css - minimal styles */
body { font-family: system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial; margin: 0; padding: 16px; background:#f7f7f8; color:#111; }
.container { max-width:900px; margin: 0 auto; padding: 16px; background:#fff; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.06); }
.chat-out .msg { margin:6px 0; padding:6px 8px; border-radius:6px; }
.chat-out .you { background:#e6f7ff; text-align:left; }
.chat-out .ai { background:#fff7e6; text-align:left; }
input#chat-input { width: 70%; padding: 8px; margin-right:8px; }
button { padding:8px 12px; }

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/worker/worker.py" ]; then echo "SKIP exists: worker/worker.py"; else echo "WRITE: worker/worker.py"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/worker"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/worker/worker.py" <<'PYFILE'
# worker/worker.py (filesystem queue fallback)
import os, time, json, logging
from pathlib import Path

TASK_DIR = Path(os.getenv("AI_TASK_DIR", "/tmp/ai_tasks"))
HEARTBEAT = Path(os.getenv("AI_HEARTBEAT_FILE", "/tmp/ai_worker_heartbeat"))

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ai.worker")

TASK_DIR.mkdir(parents=True, exist_ok=True)

def heartbeat():
    HEARTBEAT.write_text(str(time.time()))

def consume():
    for p in sorted(TASK_DIR.glob("*.json")):
        try:
            data = json.loads(p.read_text())
            logger.info("Processing %s", p)
            # simulate work
            time.sleep(1)
            # mark done
            (p.with_suffix(".done")).write_text("ok")
            p.unlink()
        except Exception as e:
            logger.exception("Failed processing %s: %s", p, e)

def main():
    logger.info("Worker starting")
    while True:
        heartbeat()
        consume()
        time.sleep(2)

if __name__ == "__main__":
    main()

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/scripts/run_gunicorn.sh" ]; then echo "SKIP exists: scripts/run_gunicorn.sh"; else echo "WRITE: scripts/run_gunicorn.sh"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/scripts"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/scripts/run_gunicorn.sh" <<'PYFILE'
#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="\$(cd "\$(dirname "\$0")/.." && pwd)"
VENV="\${ROOT_DIR}/venv"
if [ ! -d "\$VENV" ]; then
  echo "Virtualenv not found at \$VENV. Create with: python3 -m venv \$VENV && \$VENV/bin/pip install -r requirements.txt"
  exit 1
fi
exec "\$VENV/bin/gunicorn" -k eventlet -w 1 -b 127.0.0.1:8099 app:app

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/scripts/deploy_v2.sh" ]; then echo "SKIP exists: scripts/deploy_v2.sh"; else echo "WRITE: scripts/deploy_v2.sh"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/scripts"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/scripts/deploy_v2.sh" <<'PYFILE'
#!/usr/bin/env bash
# Non-destructive deploy helper (does NOT run sudo actions automatically)
set -euo pipefail
ROOT="\${1:-\$(pwd)}"
echo "Deploy helper - will copy config examples and show manual steps."
mkdir -p "\$ROOT/out_deploy"
cp -a deploy/systemd/*.service "\$ROOT/out_deploy/" 2>/dev/null || true
cp -a deploy/nginx/*.conf "\$ROOT/out_deploy/" 2>/dev/null || true
cp -a deploy/*.yml "\$ROOT/out_deploy/" 2>/dev/null || true
cat > "\$ROOT/out_deploy/etc_ai_agent_env_example" <<'ENV'
OPENAI_API_KEY=sk-REPLACE_ME
AI_DEFAULT_MODEL=gpt-4o-mini
ENV
echo "Created out_deploy/ with example files. Next manual steps:"
echo " - Review files in \$ROOT/out_deploy"
echo " - Copy systemd units to /etc/systemd/system/ and reload daemon"
echo " - Copy nginx conf to /etc/nginx/sites-available/ and enable it"
echo " - Secure /etc/ai-agent/env and restart services"

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/grafana_dashboard.json" ]; then echo "SKIP exists: deploy/grafana_dashboard.json"; else echo "WRITE: deploy/grafana_dashboard.json"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/grafana_dashboard.json" <<'PYFILE'
{ "annotations": { "list": [] }, "panels": [], "title": "AI Agent Overview", "schemaVersion": 16 }

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/prometheus_scrape.yml" ]; then echo "SKIP exists: deploy/prometheus_scrape.yml"; else echo "WRITE: deploy/prometheus_scrape.yml"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/prometheus_scrape.yml" <<'PYFILE'
- job_name: ai-agent
  static_configs:
    - targets: ['127.0.0.1:8099']
      labels:
        job: ai-agent

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/alert_rules.yml" ]; then echo "SKIP exists: deploy/alert_rules.yml"; else echo "WRITE: deploy/alert_rules.yml"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/alert_rules.yml" <<'PYFILE'
groups:
- name: ai-agent-rules
  rules:
  - alert: AIWorkerDown
    expr: up{job="ai-agent"} == 0
    for: 2m
    labels:
      severity: critical
    annotations:
      summary: "AI Agent service down"
  - alert: AIQueueHigh
    expr: ai_queue_tasks > 50
    for: 1m
    labels:
      severity: warning
    annotations:
      summary: "AI queue length high"

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/nginx/ai-agent.conf" ]; then echo "SKIP exists: deploy/nginx/ai-agent.conf"; else echo "WRITE: deploy/nginx/ai-agent.conf"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/nginx"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/nginx/ai-agent.conf" <<'PYFILE'
server {
  listen 80;
  server_name your.domain.tld;

  location / {
    proxy_pass http://127.0.0.1:8099;
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_http_version 1.1;
    proxy_set_header Upgrade \$http_upgrade;
    proxy_set_header Connection "upgrade";
    proxy_read_timeout 120;
  }

  location /static/ {
    alias /opt/ai-agent/dashboard/static/;
    expires 1d;
  }

  location /metrics {
    allow 127.0.0.1;
    deny all;
    proxy_pass http://127.0.0.1:8099/metrics;
  }
}

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/systemd/ai-agent.service" ]; then echo "SKIP exists: deploy/systemd/ai-agent.service"; else echo "WRITE: deploy/systemd/ai-agent.service"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/systemd"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/systemd/ai-agent.service" <<'PYFILE'
[Unit]
Description=AI Agent Web Service
After=network.target

[Service]
User=aiagent
Group=aiagent
EnvironmentFile=/etc/ai-agent/env
WorkingDirectory=/opt/ai-agent/dashboard
ExecStart=/opt/ai-agent/venv/bin/gunicorn -k eventlet -w 1 -b 127.0.0.1:8099 app:app
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/systemd/ai-agent-worker.service" ]; then echo "SKIP exists: deploy/systemd/ai-agent-worker.service"; else echo "WRITE: deploy/systemd/ai-agent-worker.service"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/systemd"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/deploy/systemd/ai-agent-worker.service" <<'PYFILE'
[Unit]
Description=AI Agent Worker
After=network.target

[Service]
User=aiagent
Group=aiagent
EnvironmentFile=/etc/ai-agent/env
WorkingDirectory=/opt/ai-agent
ExecStart=/opt/ai-agent/venv/bin/python worker/worker.py
Restart=on-failure
RestartSec=5
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/requirements.txt" ]; then echo "SKIP exists: requirements.txt"; else echo "WRITE: requirements.txt"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/requirements.txt" <<'PYFILE'
flask
flask-socketio
gunicorn
eventlet
prometheus_client
python-dotenv
requests
pytest

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/Makefile" ]; then echo "SKIP exists: Makefile"; else echo "WRITE: Makefile"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/Makefile" <<'PYFILE'
.PHONY: venv install test run package lint

venv:
	python3 -m venv venv
	. venv/bin/activate && pip install --upgrade pip

install: venv
	. venv/bin/activate && pip install -r requirements.txt

test:
	. venv/bin/activate && pytest -q

run:
	. venv/bin/activate && cd dashboard && python app.py

package:
	zip -r ai-agent-release.zip . -x .git/* venv/*

lint:
	flake8 .

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/.github/workflows/ci.yml" ]; then echo "SKIP exists: .github/workflows/ci.yml"; else echo "WRITE: .github/workflows/ci.yml"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/.github/workflows"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/.github/workflows/ci.yml" <<'PYFILE'
name: CI
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v4
        with:
          python-version: "3.10"
      - run: python -m pip install --upgrade pip
      - run: pip install -r requirements.txt
      - run: pytest -q

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/docs/deploy.md" ]; then echo "SKIP exists: docs/deploy.md"; else echo "WRITE: docs/deploy.md"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/docs"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/docs/deploy.md" <<'PYFILE'
# Deploy Instructions (summary)

1. Copy systemd units under /etc/systemd/system/
2. Create /etc/ai-agent/env with secure permissions (600) and add OPENAI_API_KEY (do not commit)
3. Copy nginx conf to /etc/nginx/sites-available/ and enable it
4. Reload systemd and start services

PYFILE
fi

if [ -f "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/README.md" ]; then echo "SKIP exists: README.md"; else echo "WRITE: README.md"; mkdir -p "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/"; cat > "/mnt/data/ai-agent-steps/Originalscript.zip_extracted/README.md" <<'PYFILE'
# AI Agent - Productionization Playbook

This repository contains an AI agent with a dashboard, worker, and deployment helpers.
See docs/deploy.md for production steps.

PYFILE
fi


echo 'Patch complete. Files written where missing under project root.'

echo 'Next steps:'
echo ' - review files under the project root'
echo ' - create virtualenv and run tests locally'
