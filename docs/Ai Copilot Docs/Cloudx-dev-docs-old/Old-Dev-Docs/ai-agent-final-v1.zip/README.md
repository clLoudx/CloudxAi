AI Agent v5 - Full production mode features

Key features added:
- Real LLM mode (set MOCK_MODE=false and provide OPENAI_API_KEY). Worker rate-limits LLM calls and uses strict JSON prompts.
- Robust prompt templates and safety rules to avoid leaking secrets or producing unsafe code.
- GitHub PR protections: PR creation includes labels and comments; protected branch workflow template added.
- Enhanced dashboard with WebSocket live logs, PR list, AI account creation UI, operations timeline, and alert view.
- Multi-queue flow (tasks, debug) and alerts routing.
- Unit tests (pytest) and a mock-run script to simulate end-to-end flows without LLM.

Run steps:
1) Edit .env: set REPO_PATH, OPENAI_API_KEY (if using real LLM), GITHUB_* variables.
2) ./install_agent.sh
3) MOCK_MODE=true ./run_agent.sh   # to run mock mode
   or
   MOCK_MODE=false ./run_agent.sh  # to run real LLM mode (be careful, costs may apply)
4) Visit http://127.0.0.1:8099 for dashboard.
5) Run tests: source venv/bin/activate && pytest -q

Security:
- Keep OPENAI_API_KEY and GITHUB_PAT in .env (not in repo).
- Prefer MOCK_MODE for testing.


Final notes:
- To inject your actual KooraKing repo, use scripts/import_repo.sh <archive> or use the Clone button in dashboard.
- Run tests with `pytest` after installing requirements.
- To enable real LLM mode, set MOCK_MODE=false and ensure OPENAI_API_KEY set.
- Production deploy: see deploy/ folder for docker-compose and systemd/supervisor templates.


LLM Chat: /api/chat endpoint now calls OpenAI when MOCK_MODE=false. Chat history saved in Redis per client. Health graphs: live CPU/Memory charts for host and workers via socketio.
